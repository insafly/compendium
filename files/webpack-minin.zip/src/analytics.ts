import * as $ from 'jquery'

// we'll calclulate clicks by document here
function createAnalytics(): object {
    let counter = 0
    let isDestroyed: boolean = false

    const listener = (): number => counter++
    $(document).on('click', listener)

    return {
        destroy() {
            $(document).off('click', listener)
            isDestroyed = true
        },

        getClilcks() {
            if (isDestroyed) return 'Analytics is destroted'
            return counter
        }
    }
}

window['analytics'] = createAnalytics()